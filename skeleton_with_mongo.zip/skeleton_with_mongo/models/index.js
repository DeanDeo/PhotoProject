//collect and export all of your models together here

module.exports = {
  Example: require("./example")
};
